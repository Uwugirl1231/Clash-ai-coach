# Clash AI Coach — iPhone PWA starter

This is a working starter app, not a deployed public website yet. It includes:
- iPhone-friendly installable PWA interface
- Server-side proxy for official Supercell player profile and battle-log endpoints
- Recent battle stats and win-rate summary
- AI coaching endpoint using OpenAI's Responses API
- Local card collection editor and basic level-aware deck heuristic

## What it cannot infer
The official battle log does not expose every troop placement, elixir decision, card cycle, or exact timing. The coach is instructed not to invent those details. For detailed tactical review, supply match screenshots or a recording to a separate vision/video workflow. The deck builder is an initial heuristic and does not yet automatically know every card's role, evolution, current balance stats, or current top-ladder win rates.

## 1. Get API keys
1. Create a Supercell developer account at https://developer.clashroyale.com/ and create a Clash Royale API key.
2. Supercell keys are IP-restricted. Set the allowed IP to your server's outbound IP. If using a provider without a stable outbound IP, consult RoyaleAPI's proxy instructions: https://docs.royaleapi.com/proxy.html
3. Create an OpenAI API key at https://platform.openai.com/api-keys. API usage is billed separately from a ChatGPT subscription.

## 2. Deploy
The easiest path is Render:
1. Create a GitHub repository and upload this folder's contents.
2. In Render, create a new Web Service from that repository. The included `render.yaml` gives the build/start commands.
3. Add environment variables `CLASH_ROYALE_API_TOKEN` and `OPENAI_API_KEY` in Render's Environment settings. Do not put either key in frontend files or share them publicly.
4. Deploy. Open the HTTPS URL on your iPhone in Safari.
5. Tap Share → Add to Home Screen.

Alternative local run:
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export CLASH_ROYALE_API_TOKEN="your-token"
export OPENAI_API_KEY="your-key"
python app.py
```

## 3. Player tag
The app is prefilled with `#2Y28JU98L`. Tap Load player after deploying and configuring the API token.

## Security
- API keys are server-side environment variables.
- Do not commit `.env` files or keys to GitHub.
- Add authentication/rate limits before sharing the deployed URL publicly.
- The app currently has no user accounts or cloud persistence; your manually entered card levels stay in that browser's local storage.

## Sources
- Official API portal: https://developer.clashroyale.com/
- API proxy notes (optional): https://docs.royaleapi.com/proxy.html
